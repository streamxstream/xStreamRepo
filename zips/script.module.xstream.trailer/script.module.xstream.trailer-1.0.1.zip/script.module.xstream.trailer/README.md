
## Willkommen beim Trailer Script für xStream!!


![xStream logo](https://github.com/streamxstream/script.module.xstream.trailer/blob/nightly/resources/icon.png?raw=true)

xStream Trailer ist ein Script mit dem man sich Trailer über Youtube, zu den passenden Stream anschauen kann.
Der bereitgestellte Inhalt der Webseiten steht in keinem Bezug zu xStream oder den Entwicklern! xStream läuft ausschließlich unter Python 3 und funktioniert somit ab Kodi Version 19 und höher!

***

Habt Ihr Fragen rund um xStream findet Ihr sicher eure Antworten in unserer FAQ.

[![FaQ aufrufen](https://raw.githubusercontent.com/streamxstream/xStreamRepo/repo/config/faq.png)](https://github.com/streamxstream/plugin.video.xstream/wiki)

***

Für alles weitere findet Ihr auch Informationen auf unserer Webseite die Ihr auch als Quelle in Kodi einbinden könnt.

[![Web Portal aufrufen](https://raw.githubusercontent.com/streamxstream/xStreamRepo/repo/config/web.png)](https://streamxstream.github.io/xStreamRepoWeb/)

***

Oder nutzt unseren Chat wenn Ihr irgendwelche anderen Fragen um xStream beantwortet haben möchtet.

[![Gitter Chat](https://raw.githubusercontent.com/streamxstream/xStreamRepo/repo/config/gitter.png)](https://gitter.im/streamxstream/community?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge)

[![Matrix.to Chat](https://raw.githubusercontent.com/streamxstream/xStreamRepo/repo/config/element.png)](https://matrix.to/#/#streamxstream_community:gitter.im)
